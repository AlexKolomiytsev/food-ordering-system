create function refresh_order_customer_m_view() returns trigger
    language plpgsql
as
$$
BEGIN
    REFRESH MATERIALIZED VIEW customer.order_customer_m_view;
    RETURN null;
END;
$$;

alter function refresh_order_customer_m_view() owner to postgres;

