create materialized view order_customer_m_view as
SELECT id,
       username,
       first_name,
       last_name
FROM customer.customers;

alter materialized view order_customer_m_view owner to postgres;

